#!/bin/bash
echo 'Deploying DDx...'